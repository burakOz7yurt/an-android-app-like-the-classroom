package com.example.plproject;

import java.util.ArrayList;

public class Teacher extends Person{

    public Teacher()
    {

    }
    public Teacher(String name, String surname, String email, String password) {
         super(name, surname, email, password);

    }

}
