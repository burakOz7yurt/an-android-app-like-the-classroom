package com.example.plproject;

public class Homework {
    private String data;


    public Homework(String data) {
        this.data = data;

    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }
}
