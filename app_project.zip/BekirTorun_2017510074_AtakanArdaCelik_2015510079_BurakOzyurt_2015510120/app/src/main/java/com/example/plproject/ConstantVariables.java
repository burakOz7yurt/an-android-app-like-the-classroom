package com.example.plproject;

public class ConstantVariables {
    static final String COURSES="Courses";
    static final String ANNOUNCEMENTS="Announcements";
    static final String HOMEWORKS="Homeworks";
    static final String DONEHOMEWORKS="DoneHomeworks";
    static final String STUDENTS="Students";
    static final String TEACHERS="Teachers";
    static final String STUDENT="student";
    static final String TEACHER="teacher";
    static final String CODE="code";
    static final String NAME="name";
    static final String DATA="data";
    static final String EMAIL="email";
    static final String DUEDATE="dueDate";
    static final String PASSWORD="password";
    static final String MESSAGES="Messages";
    static final String WHOPERSON="whoPerson";
    static final String POSTS="Posts";
    static final String TERM="term";
    static final String SUBJECT="subject";





}
