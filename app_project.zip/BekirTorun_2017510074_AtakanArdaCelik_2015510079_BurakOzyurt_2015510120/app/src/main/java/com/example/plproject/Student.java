package com.example.plproject;


public class Student extends Person {

    public Student()
    {

    }
    public Student(String name, String surname, String email, String password)
    {
        super(name, surname, email, password);
    }

}
