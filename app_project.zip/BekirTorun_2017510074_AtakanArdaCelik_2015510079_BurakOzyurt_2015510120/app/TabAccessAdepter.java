import android.widget.Switch;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.example.plproject.ChatFragment;

public class TabAccessAdepter extends FragmentPagerAdapter {

    public TabAccessAdepter(@NonNull FragmentManager fm) {
        super(fm);
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {

        switch(position)
                {
                    case 0:
                        ChatFragment chats=new ChatFragment();
                        return chats;
                    case 1:

                        return chats;
                    case 2:
                        ChatFragment chats=new ChatFragment();
                        return chats;
                }

        return null;
    }

    @Override
    public int getCount() {
        return 0;
    }
}